package com.everis.data.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.everis.data.models.Venta;
import com.everis.data.services.ProductoService;
import com.everis.data.services.VentaService;

@Controller
@RequestMapping("/venta")
public class VentaController {
	
	@Autowired
	VentaService vs;
	
	@Autowired
	ProductoService ps;
	
	@RequestMapping("")
	public String inicio(Model model) {
		model.addAttribute("lista_ventas", vs.findAll());
		return "venta.jsp";
	}
	
	@RequestMapping(value="/insertar", method = RequestMethod.POST)
	public String insertar(@RequestParam("nombre") String nombre) {
		Venta venta = new Venta(nombre);
		
		vs.save(venta);
		return "redirect:/venta";
	}

}