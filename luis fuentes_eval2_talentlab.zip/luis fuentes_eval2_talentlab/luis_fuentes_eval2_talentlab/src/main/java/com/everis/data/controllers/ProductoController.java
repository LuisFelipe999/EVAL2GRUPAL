package com.everis.data.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.everis.data.models.Producto;
import com.everis.data.services.ProductoService;

@Controller
@RequestMapping("/producto")
public class ProductoController {

@Autowired
	private ProductoService ps;

	@RequestMapping("")
	public String index(@ModelAttribute("producto") Producto producto,Model model ) {
		List<Producto> lista_productos = ps.findAll(); 
		model.addAttribute("lista_productos", lista_productos);
	
	return "producto.jsp";
	}
	
	@RequestMapping(value="/crear", method = RequestMethod.POST)
	public String crear(@Valid @ModelAttribute("producto") Producto producto) {
	System.out.println("crear "+ producto);
	
	//si el campo esta vacio entonces en consola te avisara eso
		if(producto.getNombre().isBlank()|| producto.getCaracteristicas()== null|| producto.getPrecio()== null) {
			System.out.println("Error de tipo campo vacio");
		
			return "redirect:/producto";
		}
	
	//Verificar largo de nombre
		if(producto.getNombre().length() < 3 || producto.getNombre().length() > 20) {
		
			System.out.println("Error El de longitud en el apellido/nombre");
			System.out.println("minimo de 3 carácteres y máximo de 20");
		
			return "redirect:/producto";
		}
	
	ps.insertarProducto(producto);
	
	return "redirect:/producto";
	}
	
	@RequestMapping(value="/actualizar/{id}", method = RequestMethod.GET)
	public String actualizar(@PathVariable("id") Long id,Model model) {
		System.out.println("actualizar id: "+ id);
	
		Producto producto=ps.buscarProducto(id);
		model.addAttribute("producto",producto);
	
	return "editar_producto.jsp";
	}
	
	
	@RequestMapping(value="/modificar", method = RequestMethod.PUT)
	public String modificar(@Valid @ModelAttribute("producto") Producto producto) {
		System.out.println("modificar");

	// la misma validacion de crear para que el campo no este vacio
		if(producto.getNombre().isBlank()|| producto.getCaracteristicas()== null|| producto.getPrecio()== null) {
			System.out.println("Error de tipo campo vacio");
		
		return "redirect:/producto";
		}
		
		if(producto.getNombre().length() < 3 || producto.getNombre().length() > 20) {
			
			System.out.println("Error El de longitud en el nombre");
			System.out.println("minimo de 3 carácteres y máximo de 20");
			
			return "redirect:/producto";
		}
	
	ps.modificarProducto(producto);
	
	return "redirect:/producto";
	
	}
	
	@RequestMapping(value="/eliminar", method = RequestMethod.POST)
	public String eliminar(@RequestParam("id") Long id) {
		
		System.out.println("Eliminar id: "+ id);
	
		ps.eliminarProducto(id);
	return "redirect:/producto";
	}
	
	@RequestMapping("/buscar")
	public String buscar() {
	return "redirect:/producto";
	}
}